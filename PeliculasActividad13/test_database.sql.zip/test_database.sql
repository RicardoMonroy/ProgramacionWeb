--
-- Base de datos: `test_database`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `db_peliculas`
--

CREATE TABLE `db_peliculas` (
  `id` int(4) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `tipo_pelicula` varchar(255) NOT NULL,
  `clasificacion` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `db_peliculas`
--

INSERT INTO `db_peliculas` (`id`, `nombre`, `tipo_pelicula`, `clasificacion`) VALUES
(1, 'El exorcista', 'Terror', 'C'),
(2, 'Los Otros', 'Terror', 'C'),
(3, 'Lo que el viento se llevo', 'Drama', 'B'),
(4, 'La tragedia', 'Drama', 'B'),
(5, 'El Renacido', 'Aventura', 'B'),
(6, 'El Avion', 'Aventura', 'B'),
(7, 'El Avion', 'Aventura', 'B');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `db_peliculas`
--
ALTER TABLE `db_peliculas`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `db_peliculas`
--
ALTER TABLE `db_peliculas`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
